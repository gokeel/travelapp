<div id="content"  style="min-height:400px;"> 
  <div class="frametab">
		
		<h2 style="margin:5px 0 5px 5px; color:yellow;">Terjadi Kesalahan Pada Proses</h2>
		<h3 style="color:yellow;">Pesan kesalahan:</h3>
		<h3 style="color:yellow;"><?php echo $error;?></h3>
	</div>
	<div id="end"></div>
  <!--&content--> 
</div>