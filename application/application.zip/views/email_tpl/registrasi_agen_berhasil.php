<html>
	<body>
		<p>Hai <?php echo $name;?></p>
		<p></p>
		<p>Registrasi keagenan berhasil. Berikut ini info untuk dapat login ke halaman agensi:<br />
		Username: <?php echo $username;?><br />
		Password: <?php echo $password;?></p>
		<p></p>
		<p>Proses pengadaan web subdomain anda akan kami proses secepatnya, paling lambat 1x24 jam.</p>
		<p></p>
		<p>Salam,<br />
			Admin</p>
	</body>
</html>