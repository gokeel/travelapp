<html>
	<body>
		<p>Hai <?php echo $name;?></p>
		<p></p>
		<p>Registrasi keagenan berhasil. Berikut ini info untuk dapat login ke halaman agensi:</p>
		<table>
			<tr>
				<td>Username:</td>
				<td><?php echo $username;?></td>
			</tr>
			<tr>
				<td>Password:</td>
				<td><?php echo $password;?></td>
			</tr>
		</table>
		<p>Proses pengadaan web subdomain anda akan kami proses secepatnya, paling lambat 1x24 jam.</p>
		<p></p>
		<p>>Salam,<br />
			Admin</p>
	</body>
</html>