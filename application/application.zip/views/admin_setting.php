

<div id="content"  style="min-height:400px;"> 
  <!--content--> 
	<!--<div id="topnav">
		<form style="display:inline-block; float:right; margin:5px;" name="search-box">
		<label>Cari Nama Agen</label>
		<input type="text" name="search" />
		<input type="submit" id="search-agent" value="Cari">
		</form>
	</div>-->
	<!--<div class="frametab">
		<input type="button" onclick="document.location='<?php echo base_url('index.php/admin/agent_data_page');?>'" value="ADD NEW DATA" name="Add Data" style="margin:10px; float:right;">
		<h3 style="margin:5px 0 5px 5px;">Agen Request</h3>
		<div id="data-agents"></div>
	</div>
	<div id="end"></div>-->
  <!--&content--> 
</div>
