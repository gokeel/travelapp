	<div class="row clearfix new-row">
		<div class="col-md-3 column">
			
		</div>
		<div class="col-md-6 column imgBorders">
			<h3 class="text-center font-color-2">
				Isi data anda
			</h3>
			<table>
				<tr>
					<td>Email</td>
					<td>
						<input type="text" class="tb8-large" />
					</td>
				</tr>
				<tr>
					<td>Password<br/><span style="font-size:9px;color:#FFFF66;">(8 karakter, alpha_numeric)</span></td>
					<td>
						<input type="text" class="tb8-large" />
					</td>
				</tr>
				<tr>
					<td>Ulangi Password</td>
					<td>
						<input type="text" class="tb8-large" />
					</td>
				</tr>
				<tr>
					<td>Nama Depan</td>
					<td>
						<input type="text" class="tb8-large" />
					</td>
				</tr>
				<tr>
					<td>Nama Belakang</td>
					<td>
						<input type="text" class="tb8-large" />
					</td>
				</tr>
				<tr>
					<td></td>
					<td>
						<input type="submit" class="btn btn-primary btn-submit" value="Daftar"/>
					</td>
				</tr>
			</table>
		</div>
		<div class="col-md-3 column">
			
		</div>
	</div>
