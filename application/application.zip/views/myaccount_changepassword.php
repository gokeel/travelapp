<!-- Terusan dari myaccount_leftmenu.php -->
	<div class="col-md-8 column">
		<div class="panel panel-primary account-border">
			<div id="change-password">
				<h3 class="text-center text-primary">
					Ganti Password
				</h3>
				<form method="GET">
					<table>
						<tr>
							<td>Password lama:</td>
							<td>
								<input type="password" class="tb8-large" name="passwd-old" />
							</td>
						</tr>
						<tr>
							<td>Password baru:</td>
							<td>
								<input type="password" class="tb8-large" name="passwd-new" />
							</td>
						</tr>
						<tr>
							<td>Konfirmasi password baru:</td>
							<td>
								<input type="password" class="tb8-large" name="confirm-passwd-new" />
							</td>
						</tr>
						<tr>
							<td></td>
							<td>
								<input type="submit" class="btn btn-primary btn-submit" value="Ganti password"/>
							</td>
						</tr>
					</table>
				</form>
			</div>
		</div>
	</div>

</div>