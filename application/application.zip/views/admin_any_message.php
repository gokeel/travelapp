<!--slidemenu--> 

<div class="navigator">
	<div class="pagetitle">HOME</div>
	<div style="float:right; padding5px; color:#888; margin:5px;">Your IP: <?php echo $ip_address;?></div>
</div>

<div id="content"  style="min-height:400px;"> 

  <div class="frametab">
		<h2 style="margin:5px 0 5px 5px;color:red;"><?php echo $title;?></h2>
		<p><?php echo $subtitle;?></p>
		<p><?php echo $message;?></p>
	</div>
	<div id="end"></div>
  <!--&content--> 

</div>