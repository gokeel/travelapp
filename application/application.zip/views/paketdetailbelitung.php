<style type="text/css">
<!--
.style1 {
	color: #FF9900;
	font-size:16px;
	font-weight: bold;
}
-->
</style>
<div class="main fullwidth">
<!-- IIRRRRFFFFAAANNN -->

    <div class="header-wrap"> <!-- Header Wrapper, contains Mene and Slider -->
      
   
   
<!-- HEADER IRFAAAAAANNNNNNN -->
<div class="page-title">
                        <div class="container">
                            <div style="float:left; margin-right:10px;">
                                <img src="<?php echo IMAGES_DIR;?>/promo.jpg" alt="Page Title" width="150"/>
                            </div>
                            <div class="page-title-content">
                                <h1>Paket Tour</h1>
                                <p class="page-description">
									Kami menawarkan paket-paket tour dan wisata yang telah didesain demi kenyamanan dan menjadikannya sebuah perjalanan yang berkesan. itenerary tersebut dibawah dapat berubah, kami harapkan anda melakukan kontak langsung dengan petugas kami untuk mendapatkan informasi detail.
								</p>
                            </div>
                        </div>
                    </div>
                </div> <!-- Close Header Menu -->
            </div> <!-- Close Header Wrapper -->
        <div class="page-top-stripes"></div> <!-- Page Background Stripes -->

        <div class="page"> <!-- Page -->
            <div class="breadscrumbs" style="background:#F60">
                <div class="container">
                    <ul class="clearfix">
                        <li><a href="#">Home</a>/</li>
                        <li><a href="#">Kontak</a></li>
                    </ul>
                </div>
            </div>
<!-- HEADER IRFAAAAAANNNNNNN -->
      

      
    </div>
    <!-- Close Header Menu --> 
  </div>
  <!-- Close Header Wrapper -->
  
  <!-- <div class="page-top-stripes"></div> -->
<!-- Page Background Stripes -->
  
  <div class="page"> <!-- Page -->
    <div class="main homepage">
      <div class="container"> 
        <!--Dapatkan kemudahan transaksi melalui bebasterbang.com. Kami hadir untuk memberi solusi yang efektif dalam hal perjalanan dan liburan Anda.-->
        <div class="row-fluid" style="margin-bottom:10px;">
          <!--<div class="span4 boxfix">
            <div class="content-title">
              <h3>Tiket Pesawat Murah</h3>
            </div>
            <div > 
              <!--list harga tiket murah-->
              <!--<ul class="" id="listTiketMurah">
                <li><a href="http://bebasterbang/" title=" Denpasar, Bali ke Jakarta"><strong>Denpasar, Bali</strong> <span><em>Mulai</em> <strong>IDR 308.000,00</strong></span></a></li>
                <li><a href="http://bebasterbang/" title="Penerbangan Murah dari Surabaya ke Jakarta"><strong>Surabaya</strong> <span><em>Mulai</em> <strong>IDR 198.000,00</strong></span></a></li>
                <li><a href="http://bebasterbang/" title="Penerbangan Murah dari Medan ke Jakarta"><strong>Medan</strong> <span><em>Mulai</em> <strong>IDR 480.000,00</strong></span></a></li>
                <li><a href="http://bebasterbang/pesawat/cari?d=CGK&amp;a=PNK&amp;date=2013-01-29&amp;ret_date=2013-02-05&amp;adult=1&amp;child=0&amp;infant=0" title="Penerbangan Murah dari Pontianak ke Jakarta"><strong>Pontianak</strong> <span><em>Mulai</em> <strong>IDR 511.000,00</strong></span></a></li>
                <li><a href="http://bebasterbang/pesawat/cari?d=CGK&amp;a=JOG&amp;date=2013-01-09&amp;ret_date=2013-01-16&amp;adult=1&amp;child=0&amp;infant=0" title="Penerbangan Murah dari Yogyakarta ke Jakarta"><strong>Yogyakarta</strong> <span><em>Mulai</em> <strong>IDR 290.000,00</strong></span></a></li>
                <li><a href="http://bebasterbang/pesawat/cari?d=CGK&amp;a=PDG&amp;date=2013-01-11&amp;ret_date=2013-01-18&amp;adult=1&amp;child=0&amp;infant=0" title="Penerbangan Murah dari Padang ke Jakarta"><strong>Padang</strong> <span><em>Mulai</em> <strong>IDR 401.000,00</strong></span></a></li>
                <li><a href="http://bebasterbang/pesawat/cari?d=CGK&amp;a=UPG&amp;date=2013-01-11&amp;ret_date=2013-01-18&amp;adult=1&amp;child=0&amp;infant=0" title="Penerbangan Murah dari UjungPandang, Makassar ke Jakarta"><strong>UjungPandang, Ma...</strong> <span><em>Mulai</em> <strong>IDR 440.000,00</strong></span></a></li>
                <li><a href="http://bebasterbang/pesawat/cari?d=CGK&amp;a=SOC&amp;date=2013-02-10&amp;ret_date=2013-02-17&amp;adult=1&amp;child=0&amp;infant=0" title="Penerbangan Murah dari Solo ke Jakarta"><strong>Solo</strong> <span><em>Mulai</em> <strong>IDR 290.000,00</strong></span></a></li>
                <li><a href="http://bebasterbang/pesawat/cari?d=CGK&amp;a=SRG&amp;date=2013-01-14&amp;ret_date=2013-01-21&amp;adult=1&amp;child=0&amp;infant=0" title="Penerbangan Murah dari Semarang ke Jakarta"><strong>Semarang</strong> <span><em>Mulai</em> <strong>IDR 280.000,00</strong></span></a></li>
                <li><a href="http://bebasterbang/pesawat/cari?d=CGK&amp;a=PLM&amp;date=2013-01-10&amp;ret_date=2013-01-17&amp;adult=1&amp;child=0&amp;infant=0" title="Penerbangan Murah dari Palembang ke Jakarta"><strong>Palembang</strong> <span><em>Mulai</em> <strong>IDR 290.000,00</strong></span></a></li>
                <li><a href="http://bebasterbang/pesawat/cari?d=CGK&amp;a=MDC&amp;date=2012-12-31&amp;ret_date=2013-01-07&amp;adult=1&amp;child=0&amp;infant=0" title="Penerbangan Murah dari Manado ke Jakarta"><strong>Manado</strong> <span><em>Mulai</em> <strong>IDR 813.500,00</strong></span></a></li>
                <li><a href="http://bebasterbang/pesawat/cari?d=CGK&amp;a=TJQ&amp;date=2013-01-01&amp;ret_date=2013-01-08&amp;adult=1&amp;child=0&amp;infant=0" title="Penerbangan Murah dari Tanjung Pandan ke Jakarta"><strong>Tanjung Pandan</strong> <span><em>Mulai</em> <strong>IDR 320.000,00</strong></span></a></li>
              </ul> 
            </div>
          </div>  -->
          <!--<div class="span8 boxfix">
          
            <div class="content-title">
              <h3>Hotel Promo</h3>
            </div>
            
            <div class="portfolio-wrapper portfolio-four isotope listhotel" >
            
       		<div class="portfolio-item hoverdir ecofriendly isotope-item boxfix">
           	 	<div class="portfolio-overlay"></div>
                  	<span class="portfolio-single-link" >
                        <span class="news-img-mini" >  <img src="<?php echo IMAGES_DIR;?>/hotel1_l.jpg" alt="The Sunset Bali Hotel">  </span>
                        <strong><a href="#" class="title">The Sunset Bali Hotel</a></strong> <br/>
                        <span class="starsin3">3-Stars Hotel</span><br/>
                        Bali<br/>
                        <span class="redbox">Discount 20%</span><br/>
                        <strong>IDR 650.000,00</strong>    
                    </span>
              </div>
              
              <div class="portfolio-item hoverdir ecofriendly isotope-item boxfix" >
              	<div class="portfolio-overlay">tess</div>
                  <span class="portfolio-single-link" >
                        <span class="news-img-mini" > <img src="<?php echo IMAGES_DIR;?>/hotel2_l.jpg" alt="The Sunset Bali Hotel">  </span>
                        <strong><a href="#" class="title">Favehotel Solo Baru</a></strong> <br/>
                        <span class="starsin2">2-Stars Hotel</span><br/>
                        Solo<br/>
                        <span class="redbox">Discount 20%</span><br/>
                        <strong>IDR 450.000,00</strong>  
                    </span>
                	
              </div>

             <div class="portfolio-item hoverdir ecofriendly isotope-item boxfix">
                <span class="portfolio-single-link" >
                    <span class="news-img-mini" > <img src="<?php echo IMAGES_DIR;?>/hotel3_l.jpg" alt="The Sunset Bali Hotel"></span>
                    <strong><a href="#" class="title">Hotel Kuta Paradiso</a></strong><br/>
                    <span class="starsin5">5-Stars Hotel</span><br/>
                    Bali<br/>
                    <span class="redbox">Discount 20%</span><br/>
                    <strong>IDR 1.450.000,00</strong> 
                </span>
                <div class="portfolio-overlay">tess</div>
              </div>
              
              <div class="portfolio-item hoverdir ecofriendly isotope-item boxfix">
                    <span class="portfolio-single-link" >
                        <span class="news-img-mini" ><img src="<?php echo IMAGES_DIR;?>/hotel3_l.jpg" alt="The Sunset Bali Hotel"></span>
                        <strong><a href="#" class="title">Hotel Kuta Paradiso</a></strong><br/>
                        <span class="starsin5">5-Stars Hotel</span><br/>
                        Bali<br/>
                        <span class="redbox">Discount 20%</span><br/>
                        <strong>IDR 1.450.000,00</strong>
                    </span>
                    <div class="portfolio-overlay">tess</div>
                
              </div>
              
            </div>
          </div> -->
        </div>
        
		
			
        <div>
        <!--  IRRFFFAAAAAAANNNNN -->
        
        <!-- KOLOM TIKET MURAH  -->
        <div class="span4 boxfix">
            
            <div> 
              <img src="<?php echo IMAGES_DIR;?>/belitung1fix.jpg" /> <br /><br />
              <img src="<?php echo IMAGES_DIR;?>/belitung2fix.jpg" /> <br /><br />
              <img src="<?php echo IMAGES_DIR;?>/belitung3fix.jpg" /> <br /><br />
              <img src="<?php echo IMAGES_DIR;?>/belitung4fix.jpg" /> <br /><br />
              <img src="<?php echo IMAGES_DIR;?>/belitung5fix.jpg" /> <br /><br />
              <img src="<?php echo IMAGES_DIR;?>/belitung6fix.jpg" /> <br /><br />
          </div>
          </div>
<!-- KOLOM TIKET MURAH  -->
          
<!-- IIRRFFFFFAAANN -->          
        

<!-- KOLOM HOTEL MURAH  -->       
<div class="span8 boxfix">
          
            <div class="content-title">
              <h3>Itenerary</h3>
            </div>
            
            
            
       		
            <p class="style1"> Bangka Belitung Tour</p>
            <p>
Bangka Belitung Tour (4D/3N) adalah paket tour yang kami susun untuk memenuhi keinginan wisatawan yang ingin menikmati pengalaman tour ke pulau Bangka, sekaligus ke pulau Belitung. Dengan mengikuti paket Bangka Belitung Tour (4D/3N), Anda dapat menyaksikan hampir seluruh objek wisata terfavorit dan pantai-pantai terindah yang ada di Prov.Bangka Belitung. Berikut �</p>

<p>Bangka Belitung Tour (4D/3N) adalah paket tour yang kami susun untuk memenuhi keinginan wisatawan yang ingin menikmati pengalaman tour ke pulau Bangka, sekaligus ke pulau Belitung.

Dengan mengikuti paket Bangka Belitung Tour (4D/3N), Anda dapat menyaksikan hampir seluruh objek wisata terfavorit dan pantai-pantai terindah yang ada di Prov.Bangka Belitung. Berikut rincian itinerary untuk Bangka Belitung Tour (4D/3N).</p>

<p>HARI ke 1 :<br />
Setibanya di Bandara Depati Amir Pangkalpinang, Bangka, Anda langsung kami ajak untuk tour ke Kota Sungailiat. Selama perjalanan ke Sungailiat, kita akan melewati Jembatan Baturusa, Kelenteng China kuno dan komplek Pemda kab. Bangka.<br />
Sampai di Sungailiat Anda akan menikmati Pantai Tanjung Pesona, keindahan Pantai Parai Tenggiri, putihnya pasir Pantai Matras, dan Pemandian air panas Pemali. Makan malam di local restaurant. Selanjutnya kita akan ke hotel untuk check in.
</p>

<p>HARI ke 2 :<br />
Setelah santap pagi di hotel dan check out kita akan menuju Pangkalpinang untuk berbelanja oleh�oleh makanan khas Bangka, mengunjungi galeri Batik Cual Ishadi, Museum Timah Indonesia. Selanjutnya makan siang di restaurant seafood Pantai Pasir Padi. Setelah santap siang dan menikmati keindahan pantai Pasir Padi, kita akan mengunjungi kawasan agrowisata Bangka Botanical Garden. Sampai pada waktunya Anda akan diantar ke pelabuhan untuk untuk menikmati pelayaran ke pulau Belitung. Pelayaran ini memerlukan waktu sekitar 4-5 Jam.<br /><br />
Setibanya di Belitung, Anda langsung disambut untuk kemudian diantar untuk dinner, dan check in hotel untuk istirahat.</p>

<p>HARI ke 3:<br />
Sarapan dan persiapan untuk perjalanan ke pulau-pulau; pulau Tanjung Kelayang, ke pulau Gusong (pulau pasir) snorkeling, berenang, kemudian ke pulau Lengkuas, dan pulau Burung. Makan siang, kemudian menjelajahi pulau Burung, berenang, dan snorkeling. Selanjutnya kembali ke Tanjung Kelayang. Menikmati Sunset dari Tg Pendam, makan malam, dan kembali ke Hotel untuk istirahat.</p>

<p>HARI ke 4:<br />
Sarapan, Check out Hotel, city tour untuk belanja oleh-oleh dan souvenir khas Belitung, Transfer out Bandara.</p>

<p>Biaya untuk paket Bangka Belitung Tour (4D/3N) yang kami tawarkan cukup terjangkau. Segera hubungi Customer Service kami dan dapatkan penawaran harga terbaik.<br /><br />

Berikut biaya Paket Tour Bangka Belitung 4 Hari 3 Malam<br /><br />

Biaya Paket Tour dibawah ini sudah termasuk:
<ol>

<li>Breakfast at hotels 3x </li>
<li>Lunch 3x</li>
<li>Dinner 3x</li>
<li>Tranfer in-out</li>
<li>Transportasi full AC</li>
<li>Kamar standard twin sharing (1 kamar berdua):</li>
<li>Belitung Hotel ***/****</li>
<li>Di Bangka Hotel ***/****</li>
<li>Tiket masuk ke objek-objek wisata</li>
<li>Pemandu Wisata Bahasa Indonesia</li>
<li>1 botol mineral water/person/day</li>
<li>Tour sesuai program</li>
<li>Tiket Kapal Express Bagari Bangka-Belitung</li>
</ol>

Belum termasuk:
<ul>
<li>Tiket pesawat PP</li>
<li>Tipp Guide & Driver</li>
<li>Keperluan pribadi (bill telpon, laundry, dll)</li>
</ul>
</p>

<p>
<table width="500" style="border: thin solid #999999 1px">
<tr>
<td align="center">Jumlah</td> <td colspan="4" align="center">Pilihan Hotel berbintang </td> 
</tr>
<tr>
<td align="center">Peserta</td> <td align="center">Tanjung Pesona<br />

Bahamas</td> <td align="center">Novotel Bangka<br />

Grand Hatika</td><td align="center">Red Dot<br />

Pendok Impian</td><td align="center">Hotel lainnya</td>
</tr>
<tr>
<td align="center">2-3</td> <td align="center">3.455.000</td> <td align="center">3.692.000</td><td align="center">3.410.000</td><td align="center">Hubungi Kami</td>
</tr>
<tr>
<td align="center">4-6</td> <td align="center">3.395.000</td> <td align="center">3.587.000</td><td align="center">3.270.000</td><td align="center">Hubungi Kami</td>
</tr>
<tr>
<td align="center">7-10</td> <td align="center">3.195.000</td> <td align="center">3.393.000</td><td align="center">2.995.000</td><td align="center">Hubungi Kami</td>
</tr>
<tr>
<td>11-15</td> <td align="center">2.875.000</td> <td align="center">2.952.000</td><td align="center">2.770.000</td><td align="center">Hubungi Kami</td>
</tr>
<tr>
<td align="center">15-up</td> <td align="center">Hubungi Kami</td> <td align="center">Hubungi Kami</td><td align="center">Hubungi Kami</td><td align="center">Hubungi Kami</td>
</tr>

</table>


</p>
<p><a href="http://hellotraveler.co.id/dev/index.php/webfront/pesanpaket"><strong>klik untuk pesan paket wisata ini</strong></a></p>


              

             
          </div>
          
            
            <!--  IRRFFFAAAAAAANNNNN -->
            
            
            
            
          </div>
        </div>
     </div>
<!--xxxxxxxxxxxxxxxxxxxxxxxxxxxx-->
 <div class="container" style="margin-top:20px;">       
     <!--   <div class="span12" style="height:100px;">-->
        <div class="inner untb">
          
           <div id="follow" class="text-align-center" style="background:#fff; padding:20px 0; border-bottom:1px solid #ddd;">
            <img src="<?php echo IMAGES_DIR;?>/logomaskapai/kai.jpg"/>
            <img src="<?php echo IMAGES_DIR;?>/logomaskapai/airasia.jpg"/>
            <img src="<?php echo IMAGES_DIR;?>/logomaskapai/batavia.jpg"/>
            <img src="<?php echo IMAGES_DIR;?>/logomaskapai/citylink.jpg"/>
            <img src="<?php echo IMAGES_DIR;?>/logomaskapai/garuda.jpg"/>
            <img src="<?php echo IMAGES_DIR;?>/logomaskapai/kalstar.jpg"/>
            <img src="<?php echo IMAGES_DIR;?>/logomaskapai/merpati.jpg"/>
            <img src="<?php echo IMAGES_DIR;?>/logomaskapai/sky.jpg"/>
            <img src="<?php echo IMAGES_DIR;?>/logomaskapai/sriwijaya.jpg"/>
            <img src="<?php echo IMAGES_DIR;?>/logomaskapai/trigana.jpg"/>
            <img src="<?php echo IMAGES_DIR;?>/logomaskapai/lion.jpg"/>
            <img src="<?php echo IMAGES_DIR;?>/logomaskapai/airfast.jpg"/>
          </div>
          <div class="heading_border"></div>
          
          <div class="row-fluid" style="margin:20px 0;">
          
              <div class="span6 payment">
                  <div id="follow" class="text-align-center" style="background:#fff; padding:5px; border:0px solid #ddd;">
                    <img src="<?php echo IMAGES_DIR;?>/member/asita.jpg" style="width:50px; margin-right:5px;"/>
            		<img src="<?php echo IMAGES_DIR;?>/member/iata.jpg" style="width:50px; margin-right:5px;"/>
                    <img src="<?php echo IMAGES_DIR;?>/member/angkasapura.jpg" style="width:130px; margin-right:5px;"/>
  					<img src="<?php echo IMAGES_DIR;?>/member/fastpay.jpg" style="width:130px; margin-right:5px;"/>
                  </div>
          	   </div>
          
              <div class="span6 payment">
                  <div id="follow" class="text-align-center" style="background:#fff; padding:8px 5px; border:0px solid #ddd;">
                   	<img src="<?php echo IMAGES_DIR;?>/payment/mandiri.jpg" style="width:100px"/>
            		<img src="<?php echo IMAGES_DIR;?>/payment/bca.jpg" style="width:90px"/>
                    <img src="<?php echo IMAGES_DIR;?>/payment/mastercard.jpg" style="width:60px"/>
            		<img src="<?php echo IMAGES_DIR;?>/payment/visa.jpg" style="width:70px"/>
                    <img src="<?php echo IMAGES_DIR;?>/payment/paypal.jpg" style="width:100px"/>
                  </div>
              </div>
              
          </div>
          
      </div>
    <!-- /inner--> 
  </div>
<!--  xxxxxxxxxxxxxxxxxxxxxxxxx-->
 

  
    </div>
<script>
	$( window ).load(function() {
		load_all_airport('<?php echo base_url();?>index.php/flight/get_all_airport', "#flight-from");
		load_all_airport('<?php echo base_url();?>index.php/flight/get_all_airport', "#flight-to");
		
		load_all_station('<?php echo base_url();?>index.php/train/get_all_station', "#train-from");
		load_all_station('<?php echo base_url();?>index.php/train/get_all_station', "#train-to");
	});
	
	$(document).ready(function() {
		/*search flights*/
		$('#submit-flight').click(function(event) {
			$('#result').empty();
			$('#result').append('<h4>Hasil Pencarian Data Pesawat (Urutan dari harga termurah), '+document.getElementById('flight-from').value+'-'+document.getElementById('flight-to').value+' Tanggal Berangkat: '+document.getElementById('departing').value+'</h4>');
			var form = $('#flight-form').serialize();
			event.preventDefault();
			$.ajax({
				type : "GET",
				url: '<?php echo base_url();?>index.php/flight/search_flights',
				data: form,
				cache: false,
				dataType: "json",
				success:function(data){
						if(data==''){
							$('#result').append('<p>Maaf, data tidak ada untuk rute ini.<p>');
						}
						else{
							if(data.items[0].diagnostic.status=="200"){
								var div = $("#result");
								var table = document.createElement('table');
								var thead = document.createElement('thead');
								var tr_head = document.createElement('tr');
								tr_head.appendChild(set_td_data('th', 'Maskapai'));
								tr_head.appendChild(set_td_data('th', 'Kode Penerbangan'));
								tr_head.appendChild(set_td_data('th', 'Rute & Jam'));
								tr_head.appendChild(set_td_data('th', 'Harga'));
								tr_head.appendChild(set_td_data('th', 'Pesan'));
								table.appendChild(tr_head);
								
								var tbody = document.createElement('tbody');
								
								
								for(var i=0; i<data.items[0].departures.result.length;i++){
									var tr_body = document.createElement('tr');
									tr_body.appendChild(set_td_data('td', data.items[0].departures.result[i].airlines_name));
									tr_body.appendChild(set_td_data('td', data.items[0].departures.result[i].flight_number));
									tr_body.appendChild(set_td_data('td', data.items[0].departures.result[i].full_via));
									tr_body.appendChild(set_td_data('td', data.items[0].departures.result[i].price_value));
									
									var el_td = document.createElement('td');
									var link_order = document.createElement('a');
									var str = document.createTextNode('Pesan');
									link_order.appendChild(str);
									link_order.setAttribute('href', '<?php echo base_url();?>index.php/order/order_page/flight/'+data.items[0].departures.result[i].flight_id+'/'+data.items[0].search_queries.date);
									link_order.setAttribute('class', 'border-order');
									el_td.appendChild(link_order);
									tr_body.appendChild(el_td);
									
									table.appendChild(tr_body);
									
								}
								
								div.append(table);
							}
							else {
								$('#result').append('<p style="color:red">'+data.items[0].diagnostic.error_msgs+'</p>');
							}
						}
					}
			})
		});
		/*search trains*/
		$('#submit-train').click(function(event) {
			$('#result').empty();
			$('#result').append('<h4>Hasil Pencarian Data Kereta Api, '+document.getElementById('train-from').value+'-'+document.getElementById('train-to').value+' Tanggal Berangkat: '+document.getElementById('train-pergi').value+'</h4>');
			var form = $('#train-form').serialize();
			event.preventDefault();
			$.ajax({
				type : "GET",
				url: '<?php echo base_url();?>index.php/train/search_trains',
				data: form,
				cache: false,
				dataType: "json",
				success:function(data){
						if(data==''){
							$('#result').append('<p>Maaf, data tidak ada untuk rute ini.<p>');
						}
						else{
							var div = $("#result");
							var table = document.createElement('table');
							var thead = document.createElement('thead');
							var tr_head = document.createElement('tr');
							tr_head.appendChild(set_td_data('th', 'Kereta Api (Kelas)'));
							tr_head.appendChild(set_td_data('th', 'Pergi'));
							tr_head.appendChild(set_td_data('th', 'Tiba'));
							tr_head.appendChild(set_td_data('th', 'Durasi'));
							tr_head.appendChild(set_td_data('th', 'Harga'));
							tr_head.appendChild(set_td_data('th', 'Pesan'));
							table.appendChild(tr_head);
							
							var tbody = document.createElement('tbody');
							
							
							for(var i=0; i<data.items[0].departures.result.length;i++){
								var kelas = data.items[0].departures.result[i].class_name;
								
								var tr_body = document.createElement('tr');
								tr_body.appendChild(set_td_data('td', data.items[0].departures.result[i].train_name+' ('+kelas.toUpperCase()+')'));
								tr_body.appendChild(set_td_data('td', data.items[0].departures.result[i].departure_time));
								tr_body.appendChild(set_td_data('td', data.items[0].departures.result[i].arrival_time));
								tr_body.appendChild(set_td_data('td', data.items[0].departures.result[i].duration));
								
								var td1 = document.createElement('td');
								var p1 = document.createElement('p');
								p1.appendChild(document.createTextNode('Dewasa: '+data.items[0].departures.result[i].price_adult));
								td1.appendChild(p1);
								
								var p2 = document.createElement('p');
								p2.appendChild(document.createTextNode('Anak(3-9thn): '+data.items[0].departures.result[i].price_child));
								td1.appendChild(p2);
								
								var p3 = document.createElement('p');
								p3.appendChild(document.createTextNode('Bayi: '+data.items[0].departures.result[i].price_infant));
								td1.appendChild(p3);
								/*td1.appendChild(document.createTextNode('Dewasa: '+data.items[0].departures.result[i].price_adult));
								var br = document.createElement('br');
								td1.appendChild(br);
								td1.appendChild(document.createTextNode('Anak(3-9thn): '+data.items[0].departures.result[i].price_child));
								td1.appendChild(br);
								td1.appendChild(document.createTextNode('Bayi: '+data.items[0].departures.result[i].price_infant));
								*/
								tr_body.appendChild(td1);
								
								var el_td = document.createElement('td');
								var link_order = document.createElement('a');
								var str = document.createTextNode('Pesan');
								link_order.appendChild(str);
								link_order.setAttribute('href', '<?php echo base_url();?>index.php/order/order_page/train/'+data.items[0].departures.result[i].schedule_id+'/'+data.items[0].search_queries.date);
								link_order.setAttribute('class', 'border-order');
								el_td.appendChild(link_order);
								tr_body.appendChild(el_td);
								
								table.appendChild(tr_body);
							}
							
							div.append(table);
						}
					}
			})
		});
	});
</script>



<!-- IIRRRRFFFFAAANNN -->
</div>